// Supabase login and sign-up. Students sign up with an email (confirmed by link) and a username; they log in with the email.
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const SB = (() => {
  async function finish() {
    const { data: { user } } = await sb.auth.getUser();
    const { data: p } = await sb.from('profiles').select('*').eq('id', user.id).single();
    const { data: st } = await sb.from('standing').select('banned').eq('user_id', user.id).single();
    if (!p || (st && st.banned)) { await sb.auth.signOut(); return { error: 'This account has been banned by a moderator.' }; }
    bridge(p);
    return { ok: true, role: p.role };
  }
  // TEMPORARY: the board, profile and moderator pages still read the browser's saved data until they are moved to Supabase.
  // This copies the logged-in profile there (no password) so they keep working. Delete it when those pages are converted.
  function bridge(p) {
    let u = {}; try { u = JSON.parse(Store.get('studentpulse_users')) || {}; } catch {}
    const k = p.username.toLowerCase();
    u[k] = { ...(u[k] || {}), name: p.username, role: p.role, joined: Date.parse(p.joined), bio: p.bio || '', avatar: p.avatar || '', salt: 'x', hash: 'x' };
    Store.set('studentpulse_users', JSON.stringify(u));
    Store.set('studentpulse_session', JSON.stringify({ name: p.username, role: p.role }));
  }
  return {
    async login(email, pw) {
      const { error } = await sb.auth.signInWithPassword({ email: email.trim().toLowerCase(), password: pw });
      if (error) return { error: /confirm/i.test(error.message) ? 'Please confirm your email first. Check your inbox for the link.' : 'Wrong email or password.' };
      return finish();
    },
    async signup(name, email, pw, pw2) {
      name = name.trim(); email = email.trim().toLowerCase();
      if (!/^[A-Za-z0-9_]{3,20}$/.test(name)) return { error: 'Username must be 3–20 letters, numbers or underscores.' };
      if (!/^\S+@\S+\.\S+$/.test(email)) return { error: 'Enter a valid email address.' };
      if (pw.length < 8) return { error: 'Password must be at least 8 characters.' };
      if (pw !== pw2) return { error: 'Passwords do not match.' };
      const { data: free } = await sb.rpc('username_free', { n: name });
      if (!free) return { error: 'That username is taken.' };
      const { data, error } = await sb.auth.signUp({ email, password: pw, options: { data: { username: name }, emailRedirectTo: new URL('login.html', location.href).href } });
      if (error) return { error: error.message };
      if (data.session) return finish();   // only if confirmation is switched off in Supabase
      return { notice: 'Almost done! We sent a confirmation link to ' + email + '. Open it, then log in here.' };
    },
    logout: async () => { await sb.auth.signOut(); }
  };
})();
